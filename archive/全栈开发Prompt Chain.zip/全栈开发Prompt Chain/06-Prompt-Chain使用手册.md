# Prompt Chain 使用手册

## 1. 核心原则

Prompt Chain 的价值来自稳定的产物接口，而不是把全部阶段塞进一次超长对话。每个模块只解决一个主要决策，并把结果写成 `A00–A13` 之一；下一模块先核验文件是否新鲜、完整、与当前工作区一致，再使用它。

如果当前 Agent 没有文件写权限，让它在回复中按同名标题输出内容，再由你保存。不要因为不能写文件就省略 schema。

## 2. 通用输入变量

每个 Prompt 顶部都有变量表。复制时至少提供以下内容：

| 变量 | 含义 | 默认处理 |
|---|---|---|
| `{{PROJECT_ROOT}}` | 项目绝对路径或明确说明“无项目目录” | 缺失时只做无仓库的产品工作 |
| `{{PRODUCT_OR_TASK}}` | 产品、功能、故障或实验目标 | 缺失且无法从上下文确定时停止 |
| `{{MODE}}` | `PLAN` 或 `APPLY` | 默认 `PLAN` |
| `{{EXTERNAL_EFFECTS}}` | `DENY` 或列出精确授权动作 | 默认 `DENY` |
| `{{DATA_BOUNDARY}}` | 可读取的数据类型和禁止范围 | 默认不读 secrets、PII、`.env`、生产数据 |
| `{{TIME_OR_BUDGET}}` | 时间、token、成本或样本上限 | 缺失时提出有依据的最小范围，不伪造预算 |
| `{{KNOWN_ARTIFACTS}}` | 已存在的 Axx 文件、PRD、Issue、设计或测试 | 先验证存在性和新鲜度 |

变量不是要求全部手工填写。能从工作区和已确认产物查明的事实由 Agent 自行读取；只有会实质改变产品、架构、数据、权限、UX 或成本的缺口才询问。

## 3. 两种模式

### `MODE=PLAN`

- 允许读取授权范围内的文件和公开资料。
- 允许生成分析、计划、草稿和本地文档，前提是用户已要求产出文档。
- 不修改产品代码、依赖、tracker、云资源或生产状态。
- 默认不 commit、push、发布或部署。

### `MODE=APPLY`

- 允许在明确工作区和文件范围内完成可逆修改并运行已有验证。
- 遇到 R2 架构、数据、权限、兼容性或核心 UX 决策时先展示方案和回滚。
- R3 外部或破坏性动作仍需对象级、当次明确的 `R3_ACTION_AUTHORIZATION`；G5/G6 的 readiness/design 决定不能替代它。

## 4. 审批门 G0–G6

| Gate | 决定 | 未通过时允许做什么 |
|---|---|---|
| G0 数据与任务边界 | 项目、数据、隐私、成本和允许动作 | 只读公开资料与不含敏感数据的本地事实 |
| G1 问题证据 | 目标用户、痛点、现有替代和证据是否足够 | 继续调研，不承诺解决方案 |
| G2 产品承诺 | 范围、成功指标、非目标和优先级 | 保持草案，不进入正式规格 |
| G3 架构与风险 | 数据模型、权限、安全、依赖、兼容和回滚 | 只做 prototype/ADR 备选，不实施高影响改动 |
| G4 实现授权 | 当前 slice、工作区写入、依赖和验证范围 | 保持 plan，不改代码或 tracker |
| G5 上线与生产 readiness | 环境、发布对象、凭据、回滚、观测和责任人是否就绪 | 只做 readiness/dry-run，不部署或访问生产 |
| G6 实验/晋升 design | 实验设计、流量、停止规则、Memory/Skill 采纳方案是否可进入动作提案 | 只生成实验或候选提案，不 launch/publish/adopt |

审批门不是一句“继续”就永久生效。G5/G6 的通用“通过”只表示 readiness/design；真实发布、生产读写或实验 launch 必须另列 `R3_ACTION_AUTHORIZATION`，逐项写 Target、Action、Expected effect、Credential scope（不含值）、Cost、Rollback、Verification、Idempotency/duplicate guard、Expiry。目标环境、数据集、仓库、分支、成本或副作用变化后必须重新确认。

## 5. Skill 调用规则

Prompt 中会列出“推荐 Skill”。使用规则：

1. Skill 已安装时，按平台支持方式显式加载 exact identifier。
2. Skill 未安装时，执行 Prompt 中已写明的方法，不声称调用成功。
3. `disable-model-invocation: true` 或 Codex `allow_implicit_invocation: false` 的 Skill 必须由用户显式选择，不能由另一个 Prompt 悄悄代替授权。
4. 调用 Skill 只选择方法，不扩大文件、网络、Git、tracker、凭据或生产权限。
5. 同职责 Skill 采用“一主一辅”，避免同时加载多个重叠的大型规则包。

## 6. 标准产物契约

每个 `Axx` 文件都必须包含以下元信息：

```markdown
# <Artifact title>

## Metadata
- Module: Mxx
- Status: draft | reviewed | approved | superseded
- Created/updated: YYYY-MM-DD
- Inputs: <文件和版本>
- Evidence level: static | dry-run | fixture | local-smoke | external-read | real-side-effect
- Mode: PLAN | APPLY

## Facts
## Decisions
## Assumptions
## Open questions
## Risks and reversibility
## Acceptance evidence
## Handoff
```

模块可以增加专用章节，但不得删除 Facts/Decisions/Assumptions/Open questions 的区分。

## 7. 产物交接

```text
A00 Context Pack
  -> A01 Project Charter
  -> A02 Opportunity Brief
  -> A03 Problem Evidence
  -> A04 Product Strategy
  -> A05 Product Spec
  -> A06 Prototype Evidence
  -> A07 Architecture and Tickets
  -> A08 Implementation Report
  -> A09 Quality Evidence
  -> A10 Release Readiness
  -> A11 Production Learning
  -> A12 Experiment Decision
  -> A13 Retrospective
  -> 下一轮 A02/A03 或规则候选池
```

后一模块必须检查：输入是否存在、状态是否允许消费、是否晚于相关代码或决策、是否存在相互矛盾的 superseding artifact。不能只因文件名存在就继续。

## 8. 四条推荐场景链

### Idea to MVP

`M00 → M01 → M02 → M03 → G1 → M04 → G2 → M05 → M06 → M07 → G3/G4 → M08 → M09 → M10 → G5 → STOP → R3 proposal → R3_ACTION_AUTHORIZATION → receipt → M11 → M13`

资源有限时可以缩小调研样本和原型范围，但不能跳过 G2、G3、G5。

### Existing product feature

`M00 → M03（利用现有反馈）→ M04 → M05 → M07 → G3/G4 → M08 → M09 → M10 → G5 → STOP → R3 proposal → R3_ACTION_AUTHORIZATION → receipt → M11 → M13`

若需求与架构已由新鲜、已批准的产物覆盖，可跳过重复访谈，但必须记录复用依据。

### Bug or incident

`M00 → M11（只读现象）→ M08 systematic-debugging → M09 regression/security review → M10 release-readiness → G5 → STOP → R3 proposal → R3_ACTION_AUTHORIZATION → receipt → M11 verify → M13`

没有稳定复现，或缺少限定 provider、project、时间窗、数据范围和查询动作的 `R3_ACTION_AUTHORIZATION` 时，停在诊断，不用猜测 patch。

### Post-launch iteration

`M00 → M11 → M03 → M12 → G6 design → STOP → G5 readiness → STOP → R3 proposal → R3_ACTION_AUTHORIZATION → receipt → M11 analyze → M04/M05 update → M07–M10 → M13`

实验结论必须包含样本、暴露、护栏、数据质量和停止条件；“指标上涨”不自动证明因果。未执行发布或 launch 时，receipt 与 M11 只能记录 `Not deployed / no production verification` 或 `Not launched / no production verification`。

## 9. 跨会话恢复

恢复时不要把整段历史重新粘贴。提供：

```markdown
## Goal
## Current module
## Approved gates
## Authoritative artifacts
## Latest evidence
## Open risks
## Next safe action
```

Agent 必须将该摘要与当前文件、代码和外部只读状态重新核对。摘要与事实冲突时，以新鲜证据为准，并记录修正。

## 10. 何时不使用完整链

- 文字修正、明确的小型代码改动：直接使用 M08/M09 的轻量路径。
- 只读解释：使用 M00 后回答，不创建多余产物。
- 已知根因的机械修复：可跳过完整 M03–M07，但仍需验收和验证。
- 单次架构咨询：使用 M07 的 `MODE=PLAN`，不自动进入实现。
- 生产事故：优先稳定、证据和回滚，不在事故中启动完整产品发现。

## 11. 质量检查

Prompt Chain 完成不等于产品完成。每一轮至少检查：

- 需求与验收是否双向可追溯。
- 事实和推断是否分开。
- 是否存在未授权副作用。
- 输出是否提供新鲜验证，而不是理论预期。
- 是否只修改当前 slice。
- 是否留下 secrets、PII、临时日志或不再使用的产物。
- Spec 与 Standards 两轴的重要 finding 是否关闭。
