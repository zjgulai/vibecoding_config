# M08：全栈实现与 TDD

## 用途

在 G4 通过后，一次实现一个垂直 slice，保留最小 diff 和新鲜验证。也包含已知/未知根因的 Debug 路由。

推荐 Skill：`implementation-orchestration`、`tdd`、`systematic-debugging`、目标仓库 `implement` 的批次思路。必须移除自动 commit。

## 输入变量

```text
{{PROJECT_ROOT}}
{{A07_PATH}}
{{CURRENT_TICKET_ID}}
{{G4_APPROVAL}}
{{MODE}} = APPLY
{{ALLOWED_FILES}}
{{DEPENDENCY_CHANGES}} = DENY 或精确授权
```

## 可复制 Prompt

```text
你正在执行 M08「全栈实现与 TDD」。只有 G4 对当前 slice 明确通过时才能改代码。

输入：
- PROJECT_ROOT: {{PROJECT_ROOT}}
- A07_PATH: {{A07_PATH}}
- CURRENT_TICKET_ID: {{CURRENT_TICKET_ID}}
- G4_APPROVAL: {{G4_APPROVAL}}
- MODE: {{MODE}}
- ALLOWED_FILES: {{ALLOWED_FILES}}
- DEPENDENCY_CHANGES: {{DEPENDENCY_CHANGES}}

启动检查：
1. 读取指令、A07 中当前 ticket、相关代码/测试/规范源；检查工作区状态。发现与允许文件重叠的未知改动时停止。
2. 验证前置 ticket 完成证据、接口名称、acceptance 和最窄验证命令。G4 缺失、ticket 不明确或依赖未满足时保持 PLAN。
3. implementation-orchestration 只在用户显式选择且有已确认 tickets 时加载。目标仓库 implement 的“自动 commit”不适用。

执行规则：
4. 先搜索现有实现、调用点、工具函数和测试；优先复用。只改当前 slice 所需内容，不预做后续 ticket、不全局格式化。
5. 新行为/已知修复：加载 tdd。在 public seam 写一个能因目标行为缺失而失败的测试；运行确认是正确 red；写最小实现；运行 green；只在 green 上做必要重构并复验。
6. 根因不明、flaky、性能或跨模块故障：先加载 systematic-debugging。定义 exact symptom/pass-fail command，缩减复现，提出可证伪预测，一次改变一个变量；根因有证据后再写 regression test 和 fix。
7. 连续三次验证失败、patch 相互干扰或范围膨胀时停止局部修补，重新审查 data/state/dependency/failure boundary。
8. 前端同时覆盖 loading/empty/error/disabled/success、responsive、keyboard/focus、accessibility 和实际页面检查。
9. 后端同时检查 validation、authn/authz、error semantics、idempotency、transaction/concurrency、timeout/retry、logging redaction 和 compatibility。
10. 数据库改动必须有 forward、rollback/repair、compatibility window 和隔离验证；未经授权不连接真实数据库。
11. AI 功能实现必须保留 deterministic seam、provider boundary、prompt/model/config 版本、fallback、cost/latency observation 和 eval fixtures。
12. 不安装依赖、不改 lockfile、不读取 secrets、不 commit/push/Issue/PR/deploy，除非这些精确动作另行授权。
13. 每个行为增量先运行最窄验证；共享接口/配置改变后扩大到相关 regression、lint、typecheck、build。工具输出截断时重新获取，不声称通过。
14. 删除临时 instrumentation、debug code、测试数据和孤儿产物。

输出 `A08-implementation-report.md`：

# A08 Implementation Report
## Metadata
## Facts
## Decisions
## Assumptions
## Open questions
## Risks and reversibility
## Acceptance evidence
## Ticket and acceptance
## Preflight
- Worktree status
- Existing patterns reused
- Allowed write set

## Red/diagnostic evidence
命令、关键结果、证据层级；未运行写 not run。

## Changes
逐文件说明行为原因，不写流水账。

## Green and regression evidence
| Check | Command | Result | Evidence level |

## Frontend/backend/data/AI special checks
## Scope review
## Unresolved risks
## External actions not performed
## Handoff
给出固定 review range、A05/A07、changed files 和未验证项。

完成标准：当前 slice 的验收有新鲜证据；diff 最小；用户变更未被覆盖；没有自动 commit 或范围外副作用。
```
